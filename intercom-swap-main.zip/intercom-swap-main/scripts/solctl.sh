#!/usr/bin/env bash
set -euo pipefail
node scripts/solctl.mjs "$@"

