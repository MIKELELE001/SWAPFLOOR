#!/usr/bin/env bash
set -euo pipefail
node scripts/lnctl.mjs "$@"

